import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from '@nuxt/ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _5ca81e1a = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _60ca13cf = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _8e9ea30e = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _2865c4b9 = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _7592e313 = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _0f300806 = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))
const _50d9445d = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active-class',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _5ca81e1a,
    children: [{
      path: "",
      component: _60ca13cf,
      name: "home"
    }, {
      path: "login",
      component: _8e9ea30e,
      name: "login"
    }, {
      path: "register",
      component: _8e9ea30e,
      name: "register"
    }, {
      path: "profile/:username",
      component: _2865c4b9,
      name: "profile"
    }, {
      path: "settings",
      component: _7592e313,
      name: "settings"
    }, {
      path: "article/:slug",
      component: _0f300806,
      name: "article"
    }, {
      path: "editor",
      component: _50d9445d,
      name: "editor"
    }]
  }],

  fallback: false
}

function decodeObj(obj) {
  for (const key in obj) {
    if (typeof obj[key] === 'string') {
      obj[key] = decode(obj[key])
    }
  }
}

export function createRouter () {
  const router = new Router(routerOptions)

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    const r = resolve(to, current, append)
    if (r && r.resolved && r.resolved.query) {
      decodeObj(r.resolved.query)
    }
    return r
  }

  return router
}
